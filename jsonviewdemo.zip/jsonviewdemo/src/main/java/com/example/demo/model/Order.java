package com.example.demo.model;

import com.example.demo.view.Views;
import com.fasterxml.jackson.annotation.JsonView;
import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class Order {
    @Id
    private Long id;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    private String product;

    private Double  amount;

    private String status;

    @JsonView(Views.UserDetails.class)
    public User getUser() {
        return user;
    }
}
