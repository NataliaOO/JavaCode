package com.example.libraryapi;

import com.example.libraryapi.model.Book;
import com.example.libraryapi.repository.BookRepository;
import com.example.libraryapi.repository.AuthorRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.servlet.MockMvc;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

@SpringBootTest
@Testcontainers
public class BookControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private BookRepository bookRepository;

    @Autowired
    private AuthorRepository authorRepository;

    @Container
    public static PostgreSQLContainer<?> postgres = new PostgreSQLContainer<>("postgres:15")
            .withDatabaseName("librarydb")
            .withUsername("user")
            .withPassword("password");

    @BeforeEach
    void setUp() {
        // Перед каждым тестом очищаем репозиторий
        bookRepository.deleteAll();
    }

    @Test
    public void testCreateBook() throws Exception {
        // Создаем JSON для новой книги
        String newBookJson = """
            {
                "title": "New Book",
                "author": {"id": 1},
                "genre": "Fiction",
                "publishedDate": "2023-01-01"
            }
        """;

        // Выполняем запрос на добавление книги
        mockMvc.perform(post("/api/books")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(newBookJson))
                .andExpect(MockMvcResultMatchers.status().isCreated())
                .andExpect(MockMvcResultMatchers.jsonPath("$.title").value("New Book"));
    }

    @Test
    public void testGetBookById() throws Exception {
        // Создаем книгу в базе данных
        Book book = new Book();
        book.setTitle("Test Book");
        bookRepository.save(book);

        // Выполняем запрос на получение книги
        mockMvc.perform(get("/api/books/" + book.getId()))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.title").value("Test Book"));
    }

    @Test
    public void testUpdateBook() throws Exception {
        // Создаем книгу в базе данных
        Book book = new Book();
        book.setTitle("Old Title");
        bookRepository.save(book);

        // Обновляем книгу
        String updatedBookJson = """
            {
                "title": "Updated Title",
                "author": {"id": 1},
                "genre": "Drama",
                "publishedDate": "2023-01-01"
            }
        """;

        mockMvc.perform(put("/api/books/" + book.getId())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(updatedBookJson))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.title").value("Updated Title"));
    }

    @Test
    public void testDeleteBook() throws Exception {
        // Создаем книгу в базе данных
        Book book = new Book();
        book.setTitle("Book to Delete");
        bookRepository.save(book);

        // Выполняем запрос на удаление книги
        mockMvc.perform(delete("/api/books/" + book.getId()))
                .andExpect(MockMvcResultMatchers.status().isNoContent());

        // Проверяем, что книга удалена
        mockMvc.perform(get("/api/books/" + book.getId()))
                .andExpect(MockMvcResultMatchers.status().isNotFound());
    }

    @Test
    public void testGetBooksWithPagination() throws Exception {
        // Создаем книги в базе данных
        for (int i = 0; i < 25; i++) {
            Book book = new Book();
            book.setTitle("Book " + i);
            bookRepository.save(book);
        }

        // Запрашиваем книги с пагинацией
        mockMvc.perform(get("/api/books?page=0&size=10&sort=title,desc"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.content.length()").value(10));
    }
}
